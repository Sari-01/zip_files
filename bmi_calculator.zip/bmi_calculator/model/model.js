const mongoose=require('mongoose');
const bmi=mongoose.Schema({
    weight:Number,
    height:Number,
    bmi:Number,
    result:String,
})

module.exports=mongoose.model('bmi',bmi)