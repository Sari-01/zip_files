const express=require("express");
const mongoose=require("mongoose");
const bodyParser=require("body-parser");
const routes=require('./routes/routes');
const app=express();

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended:true}));

mongoose.Promise=global.Promise;

app.use('/routes',routes);

const uri="mongodb+srv://Sariha:Sabarish15*@cluster0.rdbdb.mongodb.net/myFirstDatabase?retryWrites=true&w=majority";

mongoose.connect(uri,{
    useNewUrlParser:true
})
.then((data)=>
{
    console.log("Connected to Db");
})
.catch((err)=>
{
    console.log(err);
})

app.listen("8080",(req,res)=>
{
    console.log("Listening...");
})