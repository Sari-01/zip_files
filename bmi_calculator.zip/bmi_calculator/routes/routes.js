const express=require('express');
const model=require('../model/model');
const router=express.Router();

router.post('/bmi',(req,res)=>
{
    var weight=req.body.weight;
    var height=req.body.height;
    var height1=height/100;
    var bmi=parseFloat((weight/(height1*height1))).toFixed(5);
    // var bmi=((weight/(height1*height1)))
    if(bmi<18.5)
    {
        result="Your are underweight"
    }
    else if(bmi>=18.5&&bmi<=24.9)
    {
        result="You are normal"
    }
    else if(bmi>=25&&bmi<=29.9)
    {
        result="You are Overweight"
    }
    else if(bmi>=30)
    {
        result="You are Obese"
    }
    const msg=new model({
        weight:weight,
        height:height,
        bmi:bmi,
        result:result,

    })
    msg.save()
    .then((data)=>
    {
        res.send(data);
    })
    .catch((res)=>
    {
        res.send(err);
    })
})

module.exports=router;