const express = require('express');
const app = express();
const fs = require('fs');
const { finished } = require('stream');


app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(__dirname + '/websites'))

var data = fs.readFileSync('books.json');
var user_data = fs.readFileSync('user.json')
var admin_data=fs.readFileSync('admin.json')
var entry_data=fs.readFileSync('entry.json')
var entry = JSON.parse(user_data)
var entry2=JSON.parse(admin_data)
var entry3=JSON.parse(entry_data)
var entry4=JSON.parse(data)
var user_id=Object.keys(entry).length

// For getting signup for new users

app.post('/sign_up',(req,res)=>{
    var flag=0;
    var username=req.body.username;
    var dob=req.body.dob;
    var email=req.body.email;
    var password=req.body.password;
    var con_password=req.body.con_password;
    var address=req.body.address;

if(password === con_password)
{
    
    flag=1;
    
}
if(flag==1)
{
    try{
        var data={
        "username":username,
        "dob":dob,
        "email":email,
        "password":password,
        "address":address,
        
    }
    entry.push(data);
    console.log(entry);
    fs.writeFileSync('user.json',JSON.stringify(entry,null,2));
    console.log("Signned up")
    return res.redirect('./3.html');

}catch(err)
{
    console.log("Error");
}
}
else
{
    res.send("Error");
}
})

// For getting logged in 

app.post('/login',(req,res)=>
{
    var flag=0; 
    var id=req.body.username2;
    var pass=req.body.password2;

    try{
        Object.keys(entry).forEach(function(key){
            console.log(entry[key].email)
            console.log(entry[key].password);
            if((entry[key].email==id)&&(entry[key].password==pass))
            {
                console.log("Logged in")
                return res.redirect('./3.html');
                flag=1;
            }
        })
    }
catch(err)
{
    res.send(err);
    
}
if(flag==0)
{
    res.send("error")
}
})

// For admin purpose

app.post('/admin',(req,res)=>
{
    
    var username2=req.body.admin_username;
    var password2=req.body.admin_password;

    try{
        var data2={
            "username": username2,
            "password": password2
        }
        entry2.push(data2)
        console.log(entry2);
    fs.writeFileSync('admin.json',JSON.stringify(entry2,null,2));
    console.log("Successfully Admin logged in");
    return res.redirect('./5.html')
    }
    catch(err)
    {
        console.log(err);
    }

})
//To add new books by the user

app.post("/add_books",(req,res)=>{

    var book_id=req.body.book_id;
    var book_name=req.body.book_name;
    var author=req.body.author;
    var flag=0;
    
    if(book_id!==0)
    {
        flag=1;
    }
    if(flag==1)
    {
        try{
            var data4={
                "book_id":book_id,
                "book_name":book_name,
                "author":author
            }
            entry4.push(data4)
            console.log(data4)
            fs.writeFileSync('books.json',JSON.stringify(entry4,null,2))
            console.log("Books added");
            return res.redirect('./add_books.html')
        }
        catch(err)
        {
            console.log(err)
        }
    }
    else
    {
        res.send("CANNOT ADD BOOKS")
    }
})
// To show all books

app.get("/show_books_available",(req,res)=>{   
    console.log("Books shown")
    res.send(JSON.parse(data));
    
})

// Returning process

app.post("/return_book",(req,res)=>
{
    var username=req.body.username;
    var book_id=req.body.book_id;
    var book_name=req.body.book_name;
    var flag=0;
    
    Object.keys(entry4).forEach(function(key)
    {
        if(entry4[key].book_id==book_id)
        {
            flag=1;
        }
    })

    if(flag==1)
    {
        var d=new Date();
        d.toISOString().replace('T',' ')
        d.setDate(d.getDate() + parseInt(15));
       res.send("Name:"+username+"\r\n Book name:"+book_name+"\r\n Return Date:"+d.toISOString().replace('T',' '));                 
    }
})

// Taking books

app.post("/entry_book",(req,res)=>{

    var book_id=req.body.book_id;
    var book_name=req.body.book_name;
    var username=req.body.username;
    var password=req.body.password;
    var flag=0;
    var flag1=0;
    
    Object.keys(entry).forEach(function(key)
    {
        if((entry[key].email==username)&&(entry[key].password==password))
        {
            flag=1;
        }
    })
    Object.keys(entry4).forEach(function(key)
    {
        if(entry4[key].book_id==book_id)
        {
            flag1=1;
        }
    })

    if((flag==1)&&(flag1==1))
    {
        try{
            var data3={
                "book_id":book_id,
                "book_name":book_name,
                "username":username,
                "password":password
        }
            entry3.push(data3);
            console.log("Entering")
            fs.writeFileSync('entry.json',JSON.stringify(entry3,null,2));
            return res.redirect('./thank.html')
    }
    catch(err)
    {
        console.log(err)
    }
}

    else
    {
        res.send("error");
    }
    
})

// search books

app.post("/search_books",(req,res)=>{

    var book_id1=req.body.book_id1;
    var flag=0;

    try{
        Object.keys(entry4).forEach(function(key)
        {
            if(entry4[key].book_id==book_id1)
            {
                console.log("Found");
                flag=1;
            }
        })
    }
    catch(err)
    {
        console.log(err);
    }
    if(flag==1)
    {
        res.send("YEAH!!! THE BOOK THAT IS SEARCHED FOR IS FOUND.....");
    }
    else
    {
        res.send("WHOOPS!!! THE BOOK THAT IS SEARCHED FOR IS NOT FOUND.....")
    }
})

//Renewing of books

app.post("/renew_book",(req,res)=>
{
    var username=req.body.username;
    var book_id=req.body.book_id;
    var book_name=req.book_name;
    var return_date=req.body.return_date;
    var flag=0;
    var flag1=0;

    Object.keys(entry).forEach(function(key)
    {
        if((entry[key].email==username))
        {
            flag=1;
        }
    })
    Object.keys(entry4).forEach(function(key)
    {
        if(entry4[key].book_id==book_id)
        {
            flag1=1;
        }
    })
    if(flag==1&&flag1==1)
    {
        try
        {
            var d=new Date(return_date);
            d.toISOString().replace('T',' ')
            d.setDate(d.getDate() + parseInt(15));
            res.send("Your book has been renewed!!! UserName:"+username+"\r\n Book name:"+book_name+"\r\n Return Date:"+d.toISOString().replace('T',' '));                 
 
        }
    
    catch(err)
    {
        console.log(err)
    }
}
})

// Fine calculation

app.post("/fine_calculation",(req,res)=>{
    var username=req.body.username;
    var book_id=req.body.book_id;
    var return_date=req.body.return_date;
    var today_date=req.body.today_date;
    var flag=0;
    var flag1=0;

    Object.keys(entry).forEach(function(key)
    {
        if((entry[key].email==username))
        {
            flag=1;
        }
    })
    Object.keys(entry4).forEach(function(key)
    {
        if(entry4[key].book_id==book_id)
        {
            flag1=1;
        }
    })
    if(return_date==today_date)
    {
        res.send("THERE IS NO FINE!!!")
    }
    else if(flag==1&&flag1==1)
    {
        try
        {
            var d=new Date(return_date);
            var e=new Date();
            var diff=Math.abs(e - d);;
            var f=diff/(1000 * 60 * 60 * 24);
            var g=Math.trunc(f)
            var total_fine=g*1;
            res.send("TOTAL FINE AMOUNT IS : Rs. "+total_fine);
        }
        catch(err)
        {
            console.log(err);
        }
    }
})

app.listen(8118,(req,res)=>{
  console.log("Listening")
})
