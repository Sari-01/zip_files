const express=require('express');
const mongoose=require('mongoose');
const bodyParser=require('body-parser');
const app=express();
const routes=require('./routes/routes');

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended:true}));

app.use('/routes',routes);

mongoose.Promise=global.Promise;


const uri = "mongodb+srv://Sariha:Sabarish15*@cluster0.rdbdb.mongodb.net/add_value_by_name?retryWrites=true&w=majority";

mongoose.connect(uri,{
    useNewurlParser:true
})
.then((data)=>
{
    console.log("Connected to DB");
})
.catch((err)=>
{
    console.log(err);
})

app.listen("8080",(req,res)=>
{
    console.log("Listening...");
})