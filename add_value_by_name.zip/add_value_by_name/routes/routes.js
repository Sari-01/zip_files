const express=require('express');
const router=express.Router();
const model1=require('../model/model1');
const model2=require('../model/model2');

router.post('/hit1',(req,res)=>
{
    var Name=req.body.Name;
    var Value=req.body.Value;

    const msg=new model1({
        Name:Name,
        Value:Value,
    })
    msg.save()
    .then((data)=>
    {
        console.log(data);
    })
    .catch((err)=>
    {
        console.log(err);
    })
})

router.post('/hit2',(req,res)=>
{
    var Name=req.body.Name;
    var Value=req.body.Value;

    const msg=new model2({
        Name:Name,
        Value:Value,
    })
    msg.save()
    .then((data)=>
    {
        console.log(data);
    })
    .catch((err)=>
    {
        console.log(err);
    })
})

router.post('/find_value',(req,res)=>
{
    var Name=req.body.Name;

    model1.findOne({Name:Name})
    .then((data)=>
    {
        var table1=data.Value;
        console.log(table1);
        model2.findOne({Name:Name})
        .then((data1)=>
        {
            var table2=data1.Value;
            console.log(table2)
            res.send({Code:200,msg:"Value is:"+(table2+table1)})
        })

    })

})

module.exports=router;