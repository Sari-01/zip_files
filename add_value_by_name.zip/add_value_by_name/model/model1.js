const mongoose=require('mongoose');
const model1=mongoose.Schema({

    Name:String,
    Value:Number,

})
module.exports=mongoose.model('model1',model1);