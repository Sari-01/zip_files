const mongoose=require('mongoose');
const model2=mongoose.Schema({

    Name:String,
    Value:Number,

})
module.exports=mongoose.model('model2',model2);