const express=require('express');
const bodyParser=require('body-parser');
const app=express();

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended:true}));

app.post('/hex_to_dec',(req,res)=>
{
    var a=req.body.a;
    
    res.send("The decimal format is:"+parseInt(a,16))
})

app.post('/hex_bin',(req,res)=>
{
    var a=req.body.a;
    res.send("The binary form is:"+(parseInt(a, 16)).toString(2));
})

app.post('/hex_oct',(req,res)=>
{
    var a=req.body.a;
    res.send("The ocatal form is:"+(parseInt(a,16)).toString(8));
})

app.post('/bin_dec',(req,res)=>
{
    var a=req.body.a;
    res.send("The decimal format is:"+parseInt(a,2))
})

app.post('/bin_hex',(req,res)=>
{
    var a=req.body.a
    res.send("The hexadecimal format is:"+parseInt(a,2).toString(16))
})

app.post('/bin_oct',(req,res)=>
{
    var a=req.body.a
    res.send("The hexadecimal format is:"+parseInt(a,2).toString(8))
})

app.post('/oct_dec',(req,res)=>
{
    var a=req.body.a
    res.send("The decimal format is:"+parseInt(a,8))
})

app.post('/oct_hex',(req,res)=>
{
    var a=req.body.a
    res.send("The hexadecimal format is:"+parseInt(a,8).toString(16))
})

app.post('/oct_bin',(req,res)=>
{
    var a=req.body.a
    res.send("The binary format is:"+parseInt(a,8).toString(2))
})

app.post('/dec_hex',(req,res)=>
{
    var a=req.body.a;
    res.send("The hexadecimal format is:"+parseInt(a,10).toString(16));
})

app.post('/dec_oct',(req,res)=>
{
    var a=req.body.a;
    res.send("The octal format is:"+parseInt(a,10).toString(8))
})

app.post('/dec_bin',(req,res)=>
{
    var a=req.body.a;
    res.send("The binary form is:"+parseInt(a,10).toString(2));
})

app.listen(8080,(req,res)=>
{
    console.log("Listening");
})