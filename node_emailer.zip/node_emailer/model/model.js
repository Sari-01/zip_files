const mongoose=require('mongoose');

const email=mongoose.Schema({

    email:String,
    password:String,

})

module.exports=mongoose.model('email',email);