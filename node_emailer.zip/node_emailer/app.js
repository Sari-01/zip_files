const nodemailer=require('nodemailer'); //for the purpose of sending mail
const corn=require('node-cron'); // for scheduling 

app.use(bodyparser.urlencoded({extended:true}));
app.use(bodyparser.json());

const transporter=nodemailer.createTransport({

    service:'gmail',
    auth:{
        user:"sariha9601@gmail.com", // sender username
        pass:"edabmlsjuwdxwqky" // sender's hidden password
    }
});

const mailOption={

    from:"sariha9601@gmail.com",
    to:"sariha.r@vvdntech.in",
    subject:"Trying using nodemailer",
    text:"Yeah !!! Great done successfully"

};

corn.schedule('1 * * * * *',(req,res)=>  // corn-min,hour,day of the month,month,day of the week
{
transporter.sendMail(mailOption, function(error, info){
    if (error) {
      console.log(error);
    } else {
      console.log('Email sent: ' + info.response);
    }
});
});