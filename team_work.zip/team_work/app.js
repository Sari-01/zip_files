const express = require('express');
const app = express();
const mongoose=require('mongoose');
const model=require('./model/model')
const alert=require('alert');


app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(__dirname + '/link'))

mongoose.Promise = global.Promise;

const uri = "mongodb+srv://Sariha:Sabarish15*@cluster0.rdbdb.mongodb.net/myFirstDatabase?retryWrites=true&w=majority"; //mongo db connection

// for establishing db connection

mongoose.connect(uri,{
    useNewUrlParser:true  // for accessing specific connection in the db
}).then(()=>{
    console.log("connected to db")    
}).catch(err=>{
    console.log(err)
})

app.post('/register',(req,res)=>
{
    var username=req.body.username;
    var dob=req.body.dob;
    var email=req.body.email;
    var password=req.body.password;
    var con_password=req.body.con_password;
    var address=req.body.address;

    
    if(password==con_password)
    {
        var data=new model({
            "username":username,
             "dob":dob,
             "email":email,
             "password":password,
             "address":address,
        })
        data.save();
        return res.redirect('./login.html');
    }
    else
    {
        console.log(error);
    }
    
})

app.post('/login',(req,res)=>
{
    const password = req.body.password;// getting password
    const email = req.body.email; // getting username
    model.findOne({email: email, 
                    password:password})
        .then((data)=>
            {
                if(data)
                {
                  return res.redirect("./success.html") // if matched with password
                } 
                else
                {
                    window.alert("Mismatched")
                }
            })
            .catch((err)=>
            {
                alert("Mismatched")
            })
        })
        
        app.get("/show_all",(req,res)=>{   
    console.log("Shown")
    model.find({},function(err,data){  
        if(err){  
            res.send(err);  
        }  
        else{             
            res.send(data);  
            }  
    });  
    
})

app.listen(8080,(req,res)=>
{
    console.log("Listening");
})