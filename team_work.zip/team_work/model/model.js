const mongoose = require('mongoose');

const team_signup = mongoose.Schema({

    username:String,
    dob:String,
    email:String,
    password:String,
    address:String
   
});

module.exports = mongoose.model('team_signup',team_signup);