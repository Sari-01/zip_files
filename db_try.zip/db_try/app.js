const express = require('express');
const mongoose = require('mongoose');
const { json } = require('body-parser')
const bodyparser = require('body-parser');
const routes = require('./routes/routes');
const model = require('./model/model')
const app = express();



app.use(bodyparser.urlencoded({extended:true}))
app.use(bodyparser.json());

mongoose.Promise = global.Promise; // for using promises

app.use('/routes',routes);

const uri = "mongodb+srv://Sariha:Sabarish15*@cluster0.rdbdb.mongodb.net/myFirstDatabase?retryWrites=true&w=majority"; //mongo db connection

// for establishing db connection

mongoose.connect(uri,{
    useNewUrlParser:true  // for accessing specific connection in the db
}).then(()=>{
    console.log("connected to db")    
}).catch(err=>{
    console.log(err)
})

app.listen('8002',()=>{              //port number
    console.log("listening.....")
})
