const mongoose = require('mongoose');

const crud = mongoose.Schema({

    user_id:String,
    user_name: String,
    user_age:String,
    user_email: String,
    user_address:String,
    
   
});

module.exports = mongoose.model('crud',crud); //to store the entered details in the db