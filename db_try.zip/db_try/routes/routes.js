const { application } = require('express');
const express = require('express');
const model = require('../model/model');

const router = express.Router();

//creating user

router.post('/create_user',(req,res)=>
{
    model.create(req.body, (error, data) =>
    {
        user_id=req.body.user_id; // for getting user id
        user_name=req.body.user_name; // for getting user name
        user_age=req.body.user_age; // for getting user age
        user_email=req.body.user_email; // for getting user email
        user_address=req.body.user_address; // for getting user address
    
    model.find() // if the data are found then....
    .then((data)=> // function promises
    {
        var data=     // for storing the details of the user
        {
            "user_id":user_id, 
            "user_name":user_name,
            "user_age":user_age,
            "user_email":user_email,
            "user_address":user_address
        }
        res.send(data); // for sending the result as the response
    })
    .catch((err)=> // if the data not found catch block executes 
    {
        res.send(err); // the error throws
    })

    })
    
})

//updating user

router.post('/update_user',(req,res)=>
{

    model.findByIdAndUpdate(
        req.body.id,{ // for getting the id that is created automatically in the db
            user_id:req.body.user_id, // for getting user id
            user_name: req.body.user_name, // for getting user name
            user_age:req.body.user_age, // for getting user age
            user_email: req.body.user_email, // for getting user email
            user_address:req.body.user_address, // for getting user address
        }
    )
    .then((data)=> // check whether those data are found
    {
    res.send(data);  // data response as a result 
    })
    .catch((err)=> // if error occurs catch part executes
    {
        res.send(err); // response is in the form of error
    })
})

//Deleting user

router.delete('/delete_user',(req,res)=>
{
    model.findByIdAndRemove(req.body.id,(err,data)=> //findbyidandremove is used to remove the particular details of the entered id
    {
            if(!err) // if the given is not an error then this block executes
            {
                res.send(data); // the response is data of the particular id will be displayed and will be deleted in the db
            }
    });

})

//read user by id

router.get('/read_user_by_id',(req,res)=>
{
    model.findById(req.body.id,(err,data)=> // findbyid is used to find the details of the particular id
    {
        if(!err) // if the id is found in the db then this block executes
        {
            res.send(data); // response the data of particular details as the result 
        }
    })
})

// To read all users

router.get('/all',(req,res)=>{

    model.find() // to find all the data in the db 

    .then((data)=>{ 
    
        res.send(data); // sends all the details that are stored in the db as a response 
    
    })

});


module.exports = router; // for pop uping the data to the db