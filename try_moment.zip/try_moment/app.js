const express=require('express');
const moment=require('moment');
const app=express();
const bodyParser=require('body-parser');

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended:true}));


var a=moment(new Date()).format("YYYY-MM-DD");
console.log(a);
console.log(moment().subtract(1, 'weeks').endOf('isoWeek').format('dddd'));


var startDate = moment().day(1);
var endDate = moment().day(7);
var now = startDate.clone(), dates = [];
while (now.isSameOrBefore(endDate)) {
    dates.push(now.format('MM/DD/YYYY'));
    now.add(1, 'days');
}
console.log(dates)
console.log(moment().day(1));



var startdate=moment(new Date()).format("YYYY-MM-DD");
console.log(moment(startdate).add(7,'days').format("YYYY-MM-DD"))

// var getDaysBetweenDates = function(startDate, endDate) {
//     var now = startDate.clone(), dates = [];

//     while (now.isSameOrBefore(endDate)) {
//         dates.push(now.format('MM/DD/YYYY'));
//         now.add(1, 'days');
//     }
//     return dates;
// };

// var startDate = moment(new Date());
// var endDate = moment(startdate).add(7,'days');

// var dateList = getDaysBetweenDates(startDate, endDate);
// console.log(dateList);
