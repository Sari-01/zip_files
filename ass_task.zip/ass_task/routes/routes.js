const express = require('express');
const model = require('../model/model');
const bcrypt=require('bcrypt');

const nodemailer=require('nodemailer');
const jwt=require('jsonwebtoken');
const {check,validationResult}=require('express-validator');
const auth=require('../middleware/auth')
const router = express.Router();

// signingin

router.post("/signup",
[
    check("firstname","Please enter a valid username")
    .not().isEmpty(),
    check("email","Enter valid email").isEmail(),
    check("password","Enter valid password").isLength({min:6})
],
async(req,res)=>{
    const errors=validationResult(req);
    if(!errors.isEmpty())
    {
        return res.status(404).json({
            errors:errors.array()
        });
    }

    const firstname=req.body.firstname; // for getting firstname
    const lastname=req.body.lastname; // for getting lastname
    const email=req.body.email; // for getting email-id
    const password=req.body.password; // for getting password

    try
    {
        let user=await model.findOne({
            email,                               // to check whether the email already existing or not
        })
        if(user)
        {
            return res.status(400).json({
                msg:"User already exists"
            })
        }
        
        user =new model({
            firstname,
            lastname,
            email,                      // for saving the details in db
            password
        });

        const salt=await bcrypt.genSalt(10);
        user.password=await bcrypt.hash(password,salt); // bcrypting the password

        await user.save();

        const payload={
            user:
            {
                id:user.id
            }
        };

        jwt.sign(
            payload,
            "randomString",{
                expiresIn:10000   // time for expiring
            },

            (err,token)=>{
                if (err) throw err;
                res.status(200).json({
                    token
                })
                const transporter=nodemailer.createTransport({

                    service:'gmail',
                    auth:{
                        user:"sariha9601@gmail.com", // sender username
                        pass:"edabmlsjuwdxwqky" // sender's hidden password
                    }
                })
                    const mailOption={
    
                        from:"sariha9601@gmail.com",
                        to:email,  // email got from the user
                        subject:"Welcome",
                        text:"Yeah !!! Welcome you have successfully signned in :-)"
                    
                    };
                    
                    transporter.sendMail(mailOption, function(error, info){
                        if (error) {
                          console.log(error);
                        } else {
                          console.log('Email sent: ' + info.response);
                        }
                    });
            }
        );
    }
    catch(err){
        console.log(err);
        res.status(500).send("Error in saving");
    }
})
   


    router.post("/login",
[
    check("email","Please enter valid email").isEmail(), // getting email using condition
    check("password","Enter valid password").isLength({min:6}) // getting password using condition

],
async(req,res)=>
{
    const errors=validationResult(req);
    if(!errors.isEmpty())
    {
        return res.status(400).json({
            errors:errors.array()
        })
    }

    const email=req.body.email; // for getting email
    const password=req.body.password; // for getting password
    try
    {
        let user=await model.findOne({
            email
        });
        if(!user)
        {
            return res.status(400).json({
                msg:"User not exists"         // if no user matched
            });
        }
        const isMatch=await bcrypt.compare(password,user.password); // bcrypting 

        if(!isMatch)
        {
            return res.status(400).json({
                msg:"Incorrect password"  // if password mismatched
            });
        }

        const payload={
            user:{
                id:user.id
            }
        }

        jwt.sign(
            payload,
            "randomString",
            {
                expiresIn:3600    // token expiring time
            },
            (err,token)=>{
                if(err) throw err;
                res.status(200).json({
                    token         // generates a token
                });
            }
        )
    }
    catch(err)
    {
        console.log(err);
        res.status(500).json({
            msg:"Server error"
        });
    }
})


router.get("/me",auth,async(req,res)=>
{
    try
    {
        const user=await model.findById(req.user.id);
        res.json(user);                               // if the token matched the details are viewed
    }catch(e)
    {
        console.log(e);
        res.send({ message: "Error in Fetching user" }); // if not error throws
    }
})
    


module.exports = router;