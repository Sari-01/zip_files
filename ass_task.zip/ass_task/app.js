const express=require('express');
const app=express();
const bcrypt=require('bcrypt');
const nodemailer=require('nodemailer');
const mongoose=require('mongoose');
const bodyparser=require('body-parser');
const model=require('./model/model');
const routes=require('./routes/routes');
const auth=require('./middleware/auth')

app.use(bodyparser.urlencoded({extended:true}))
app.use(bodyparser.json());

app.use('/routes',routes);

mongoose.Promise = global.Promise; // for using promises

const uri = "mongodb+srv://Sariha:Sabarish15*@cluster0.rdbdb.mongodb.net/myFirstDatabase?retryWrites=true&w=majority"; //mongo db connection

// for establishing db connection

mongoose.connect(uri,{
    useNewUrlParser:true  // for accessing specific connection in the db
}).then(()=>{
    console.log("connected to db")    
}).catch(err=>{
    console.log(err)
})

app.listen('8089',()=>{              //port number
    console.log("listening.....")
})
