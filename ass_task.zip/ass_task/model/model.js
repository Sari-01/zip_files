const mongoose = require('mongoose');

const ass_task = mongoose.Schema({

  firstname:String,
  lastname:String,
  email:String,
  password:String
    
   
});

module.exports = mongoose.model('ass_task',ass_task);