const express=require('express');
const app=express();
const fs=require('fs');
const MongoClient=require('mongodb').MongoClient;
const {DB} =require('mongodb');
const { stringify } = require('querystring');

const uri="mongodb+srv://Sariha:Sabarish15*@cluster0.rdbdb.mongodb.net/myFirstDatabase?retryWrites=true&w=majority";

MongoClient.connect(uri,(err,client)=>
{
    if(err)
    {
        console.log(err);
    }
    else
    {
        console.log("connected")
    }
})
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

var user_data = fs.readFileSync('user.json');
var entry=JSON.parse(user_data);

// Creating user

app.post('/create_user',(req,res)=>
{
    var user_id=req.body.user_id;
    var user_name=req.body.user_name;
    var user_age=req.body.user_age;
    var user_email=req.body.user_email;
    var user_address=req.body.user_address;

    try
    {
        var data=
        {
            "user_id":user_id,
            "user_name":user_name,
            "user_age":user_age,
            "user_email":user_email,
            "user_address":user_address
        }
        entry.push(data);
        console.log(entry);
    fs.writeFileSync('user.json',JSON.stringify(entry,null,2));
    }
    catch(error)
    {
        res.send("file upload err")
        console.log(error);
    }
})

//Update user

app.post('/update_user',(req,res)=>
{
    var user_id=req.body.user_id;
    var user_name=req.body.user_name;
    var user_age=req.body.user_age;
    var user_email=req.body.user_email;
    var user_address=req.body.user_address;
    var flag=0;

    Object.keys(entry).forEach(function(key)
    {
        if(entry[key].user_id==user_id)
        {
            entry[key].user_name=user_name;
            entry[key].user_age=user_age;
            entry[key].user_email=user_email;
            entry[key].user_address=user_address;
            flag=1;
                  
        }
    })
    console.log(entry);
    fs.writeFileSync('user.json',JSON.stringify(entry,null,2));

    if(flag==1)
    {
        console.log("Updated");
    }
    else 
    {
        console.log("Data not found");
    }
})

//Delete user

app.delete('/delete_user',(req,res)=>
{
    var user_id=req.body.user_id;
    var flag=0;

    Object.keys(entry).forEach(function(key)
    {
        if(entry[key].user_id==user_id)
        {
            delete entry[key];
            flag=1;
        }

    })
    console.log(entry);
    fs.writeFileSync('user.json',JSON.stringify(entry,null,2));

    if(flag==1)
    {
        console.log("Deleted");
    }
    else
    {
        console.log("Data not found");
    }
})

//Read user by id

app.get('/read_user_by_id',(req,res)=>
{
    var user_id=req.body.user_id;
    var flag=0;

    Object.keys(entry).forEach(function(key)
    {
        if(entry[key].user_id==user_id)
        {
            res.send(entry[key]);
            flag=1;
        }
    })

    if(flag==1)
    {
        console.log("Displayed");
    }
    else
    {
        console.log("Data not found");
    }

})

//Read all users

app.get('/read_all_users',(req,res)=>
{
    console.log("All details shown")
    res.send(JSON.parse(user_data));
})

//Port number

var listener=app.listen(8080,(req,res)=>
{
    console.log("Listening at port number "+listener.address().port);
})
