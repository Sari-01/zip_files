const express = require('express');
const app = express();
const fs = require('fs');
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
const routes = require('./routes/routes.js')(app, fs);
app.listen(8000,(req,res)=>{
  console.log("Listening")
})