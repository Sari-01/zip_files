const express = require('express');
const router = express.Router();
const model = require('../model/model');
global. Count1 = 0,Count2=0,Count3=0,Count4=0,Count5=0;

router.post('/api_1',(req,res)=>
{
    var Api_name="api_1";
    
    model.findOne({Api_name:Api_name})
    .then((data)=>
    {
        if(data)
        {
        
            model.findOneAndUpdate({Api_name:Api_name},{$set:{Count:data.Count+1}},{new:true})
            .then((data)=>
            {
                
                res.send(data)
            })
        }
        else if(!data)
        {
            
            const msg=new model({
                Api_name:Api_name,
                Count:Count1+1,
            })
            msg.save()
            .then((data)=>
            {
                res.send(data)
            })
        }
    })
})

router.post('/api_2',(req,res)=>
{
    var Api_name="api_2";
    
    model.findOne({Api_name:Api_name})
    .then((data)=>
    {
        if(data)
        {
        
            model.findOneAndUpdate({Api_name:Api_name},{$set:{Count:data.Count+1}},{new:true})
            .then((data)=>
            {
                
                res.send(data)
            })
        }
        else if(!data)
        {
            
            const msg=new model({
                Api_name:Api_name,
                Count:Count2+1,
            })
            msg.save()
            .then((data)=>
            {
                res.send(data)
            })
        }
    })
})

router.post('/api_3',(req,res)=>
{
    var Api_name="api_3";
    
    model.findOne({Api_name:Api_name})
    .then((data)=>
    {
        if(data)
        {
        
            model.findOneAndUpdate({Api_name:Api_name},{$set:{Count:data.Count+1}},{new:true})
            .then((data)=>
            {
                
                res.send(data)
            })
        }
        else if(!data)
        {
            
            const msg=new model({
                Api_name:Api_name,
                Count:Count3+1,
            })
            msg.save()
            .then((data)=>
            {
                res.send(data)
            })
        }
    })
})

router.post('/api_4',(req,res)=>
{
    var Api_name="api_4";
    
    model.findOne({Api_name:Api_name})
    .then((data)=>
    {
        if(data)
        {
        
            model.findOneAndUpdate({Api_name:Api_name},{$set:{Count:data.Count+1}},{new:true})
            .then((data)=>
            {
                
                res.send(data)
            })
        }
        else if(!data)
        {
            
            const msg=new model({
                Api_name:Api_name,
                Count:Count4+1,
            })
            msg.save()
            .then((data)=>
            {
                res.send(data)
            })
        }
    })
})

router.post('/api_5',(req,res)=>
{
    var Api_name="api_5";
    
    model.findOne({Api_name:Api_name})
    .then((data)=>
    {
        if(data)
        {
        
            model.findOneAndUpdate({Api_name:Api_name},{$set:{Count:data.Count+1}},{new:true})
            .then((data)=>
            {
                
                res.send(data)
            })
        }
        else if(!data)
        {
            
            const msg=new model({
                Api_name:Api_name,
                Count:Count5+1,
            })
            msg.save()
            .then((data)=>
            {
                res.send(data)
            })
        }
    })
})

module.exports = router;