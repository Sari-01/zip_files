const mongoose=require('mongoose');
const api_hit=mongoose.Schema({

    Api_name:String,
    Count:Number,

})
module.exports=mongoose.model('api_hit',api_hit);