const express=require('express');
const bodyParser=require('body-parser');
const mongose=require('mongoose');
const routes=require('./routes/routes');
const { default: mongoose } = require('mongoose');
const app=express();

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended:true}));

app.use('/routes',routes);

mongose.Promise=global.Promise;

const uri = "mongodb+srv://Sariha:Sabarish15*@cluster0.rdbdb.mongodb.net/api_hit?retryWrites=true&w=majority";

mongoose.connect(uri,{
    useNewurlParser:true
})
.then(()=>
{
    console.log("Connected to DB");
})
.catch(()=>
{
    console.log(err);
})

app.listen('8080',(req,res)=>
{
    console.log("Listening...");
})