const express= require('express');
const app=express();
const bodyParser=require('body-parser');
const mysql=require('mysql');
const { urlencoded } = require('body-parser');

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended:true}));

const connection =mysql.createConnection({
    host:'sariha.cq1vulea5mff.us-east-1.rds.amazonaws.com',
    port:'3306',
    user:'admin',
    password:'Sariha12345',
    database:'crud_try',

});

connection.connect((err)=>
{
    if(!err)
    {
       
        console.log("Connected to db");
    }
    else
    {
        console.log(err);
    }
})

app.post('/create_db',(req,res)=>
{
    connection.query("Create database crud_try_1",(err,result)=>
    {
        if(err) throw err;
        res.send({code:"200",msg:'Database created'});
    })
})

app.post('/create_table',(req,res)=>
{
    connection.query('Create table cust_details(id INT PRIMARY KEY,name varchar(50),area varchar(100))',(err,result)=>
    
    {
        if(err) 
        {
            res.send(err);
        }
        else
        {
            res.send({code:"200",msg:"CREATED TABLE"});
        }
    })
})

app.post('/insert_customers',(req,res)=>
{
    connection.query('Insert into cust_details (id,name,area) values(?,?,?)',[req.body.id,req.body.name,req.body.area],(err,result)=>
    {
        if (err)
        {
            res.send(err);
        }
        else
        {
            res.send({code:200,msg:'INSERTED'})
        }
    })
})

app.put('/update_customers',(req,res)=>
{
    connection.query('Update cust_details SET area=?, name=? where id=?',[req.body.area,req.body.name,req.body.id],(err,result)=>
    {
        if(err)
        {
            res.send(err);
        }
        else
        {
            res.send({code:"200",msg:'UPDATED'});
        }
    })
})

app.delete('/delete_customers',(req,res)=>
{
    connection.query('Delete from cust_details where id=?',[req.body.id],(err,result)=>
    {
        if(err)
        {
            res.send(err);
        }
        else
        {
            res.send({code:"200",msg:"Deleted"});
        }
    })
})


app.get('/get_all_customers',(req,res)=>
{
    connection.query('Select * from cust_details',(err,result)=>
    {
        if(err)
        {
            res.send(err);
        }
        else
        {
            res.send({code:"200",msg:result});
        }
    })
})

app.get('/get_by_id',(req,res)=>
{
    connection.query('Select * from cust_details where id=?',[req.body.id],(err,result)=>
    {
        if(err)
        {
            res.send(err);
        }
        else
        {
            res.send({code:"200",msg:result});
        }
    })
})

app.listen(8080,()=>
{
    console.log("Listening");
})
